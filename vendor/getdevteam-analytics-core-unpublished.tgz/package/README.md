# @getdevteam/analytics-core

Platform-agnostic core client for the [DevTeam Analytics & Logging Platform](https://github.com/getdevteam-ai/analytics).
Use this directly from Node or any custom JS runtime.
For a browser app use [`@getdevteam/analytics-web`](https://www.npmjs.com/package/@getdevteam/analytics-web) instead.

## Install

```sh
npm install @getdevteam/analytics-core
```

## Use

```ts
import { createClient } from "@getdevteam/analytics-core";

const analytics = createClient({
  key: "dts_your_secret_key",              // server side you can use a secret key
  host: "https://ingest.analytics.getdevteam.ai",
  serviceName: "checkout-worker",
});

analytics.track("invoice_generated", { amount: 4200 });
await analytics.flush();   // call before your process exits
```

You need a `dtp_` (public) or `dts_` (secret) ingest key and the ingest host URL for your environment - see [Getting a key](https://github.com/getdevteam-ai/analytics/tree/main/src/sdk#getting-a-key) in the full SDK docs.

Full client API, config options, and release process: [src/sdk README](https://github.com/getdevteam-ai/analytics/tree/main/src/sdk).
