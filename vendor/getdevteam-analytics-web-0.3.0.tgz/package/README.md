# @getdevteam/analytics-web

Browser SDK for the [DevTeam Analytics & Logging Platform](https://github.com/getdevteam-ai/analytics).
Drop it into any browser app - plain JS, Astro, Vue, Svelte, or React without the hooks - to send analytics events and logs.
Building with React and want a `useAnalytics()` hook? Pair this with [`@getdevteam/analytics-react`](https://www.npmjs.com/package/@getdevteam/analytics-react).

## Install

```sh
npm install @getdevteam/analytics-web
```

## Use

```ts
import { createAnalytics } from "@getdevteam/analytics-web";

const analytics = createAnalytics({
  key: "dtp_your_public_key",
  host: "https://ingest.analytics.getdevteam.ai",
  trackPageviews: true,   // auto-send a pageview on every route change
});

analytics.identify("user_123", { plan: "pro" });          // who the user is
analytics.track("checkout_completed", { amount: 4200 });  // something that happened
analytics.log.error("payment gateway timed out", { gateway: "stripe" });
```

Auto-captures uncaught errors and unhandled promise rejections (turn off with `autoCaptureErrors: false`), and flushes queued events when the page is hidden or closed so nothing is lost on navigation.

## User feedback

Set `allowUserFeedback: true` to render a floating feedback button (isolated in a Shadow DOM host, loaded lazily): the user gets a screenshot of the page, drawing tools, and a comment box, and the result lands in the platform's feedback inbox.
`analytics.showFeedback()` opens the overlay programmatically; it is a no-op while the feature is off or unavailable.
Customize with `feedback: { colors, accentColor, buttonLabel, title, submitLabel, commentPlaceholder, successMessage, position, zIndex, pixelRatio }`.

The screenshot is a DOM-to-canvas render: cross-origin iframes, tainted canvases, and video frames come out blank or make the capture fail, and a failed capture falls back to comment-only feedback instead of breaking the app.
See the [SDK README](https://github.com/getdevteam-ai/analytics/tree/main/src/sdk#user-feedback) for the full option table and capture boundary.

You need a public ingest key (`dtp_...`) and the ingest host URL for your environment - see [Getting a key](https://github.com/getdevteam-ai/analytics/tree/main/src/sdk#getting-a-key) in the full SDK docs.

Full client API, config options, and release process: [src/sdk README](https://github.com/getdevteam-ai/analytics/tree/main/src/sdk).
